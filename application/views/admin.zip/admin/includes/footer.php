
<div id="footer">
	<!--  start footer-left -->
	<div id="footer-left">
	 &copy; Copyright. All Rights Reserved.
	</div>
	<!--  end footer-left -->
	<div class="clear">&nbsp;</div>
</div>
</body>
</html>