<div class="admin_home_left">
 <?php if($this->session->flashdata('status')!=''){ ?>
              <p><?php echo $this->session->flashdata('status'); ?></p>  
                <?php } ?> 
		<div class="admin_home_dashboard"> 
        	<h3 class="sep"><span><?php echo 'Admin Dashboard';?> </span> </h3>
 
 	<br />
    <?php echo $this->session->userdata('success');?>
    <ul class="admin_home_dashboard_links">
	<li>
      <ul>
        <li>
          <a href="<?php echo base_url();?>admin/manage_user/listing" class="links_layout">
            Manage Users </a>
        </li>
                
      </ul>
    </li>
    <li>
      <ul>
	    <li>
          <a href="<?php echo base_url();?>admin/manage_job/listing" class="links_layout">
            Manage Jobs</a>
        </li>      
       

      </ul>
    </li>
	    <li>
      <ul>
	         
        <li>
          <a href="<?php echo base_url();?>admin/manage_message/listing" class="links_layout">
           Manage Message</a>
                     
                  </li>

      </ul>
      <ul>
	

      </ul>
    </li>
  </ul>
</ul>           
        
       
        </div>
        
        
 	</div>
   