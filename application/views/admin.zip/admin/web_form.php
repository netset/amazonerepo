<h2>Customer Register Form</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/customer_reg" method="post" enctype="multipart/form-data">
First Name* :<input type="text" name="fname" > fname <br/>
Last Name* :<input type="text" name="lname" > lname <br/>
Email id*   :<input type="text" name="email">email <br/>
Password*   :<input type="password" name="pwd">pwd <br/>
Occupation* :<input type="text" name="ocption">ocption <br/>
Mobile     :<input type="text" name="mob">mob <br/>
Address*    :<input type="text" name="adrs">adrs <br/>
Image*      :<input type="file" name="user_img">user_img <br/>
About*  :<input type="textarea" name="abt">abt <br/>
Latitude*  :<input type="text" name="lat">lat <br/>
Longitude*  :<input type="text" name="lang">lang <br/>
<input type="submit" >
</form>

<h2>Service provider Register Form</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/service_reg" method="post" enctype="multipart/form-data">
Name* :<input type="text" name="name" >  name <br/>
Email id*   :<input type="text" name="email"> email <br/>
Password*   :<input type="password" name="pwd">pwd <br/>
Mobile     :<input type="text" name="mob">mob <br/>
Address*    :<input type="text" name="adrs">adrs <br/>
Work History*  :<input type="textarea" name="work">work<br/>
Professional Training  :<input type="text" name="pt">pt <br/>
Experience*  :<input type="text" name="exp">exp <br/>
skill Id*     :<input type="textara" name="skill_id">skill_id <br/> 
Image*      :<input type="file" name="user_img">user_img <br/>   
About*  :<input type="textarea" name="abt">abt <br/>
Latitude*  :<input type="text" name="lat"> lat<br/>
Longitude*  :<input type="text" name="lang">lang <br/>

<input type="submit" >
</form>
 
 <h2>Edit Customer profile</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/edit_customer" method="post" enctype="multipart/form-data">
user_id :<input type="text" name="user_id" >   user_id<br/>
Occupation* :<input type="text" name="ocption">ocption <br/>
Mobile     :<input type="text" name="mob">mob <br/>
Address*    :<input type="text" name="adrs">adrs <br/>
About*  :<input type="textarea" name="abt">abt <br/>
Image*      :<input type="file" name="user_img">user_img <br/>
Latitude*  :<input type="text" name="lat">lat <br/>
Longitude*  :<input type="text" name="lang">lang <br/>
<input type="submit" >
</form>

<h2>Edit Service provider profile</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/edit_service" method="post" enctype="multipart/form-data">
user_id :<input type="text" name="user_id" >   user_id<br/>
Address*    :<input type="text" name="adrs">adrs <br/>  
Latitude*  :<input type="text" name="lat">lat <br/>
Longitude*  :<input type="text" name="lang">lang <br/>
Mobile     :<input type="text" name="mob">mob <br/>
skill Id*     :<input type="textara" name="skill_id">skill_id <br/>
Image*      :<input type="file" name="user_img">user_img <br/>
About*  :<input type="textarea" name="abt">abt <br/>
Work History*  :<input type="textarea" name="work">work<br/>
Professional Training  :<input type="text" name="pt">pt <br/>
Experience*  :<input type="text" name="exp">exp <br/>
<input type="submit" >
</form>
 
 
<h2>Facebook Login</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/login_fb" method="post" >
Access token:<input type="text" name="access_token" >   access_token<br/>
Role(1=customer, 2=service provider):<input type="text" name="role" >   role<br/>
<input type="submit" >
</form>

<h2>User Login Form</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/customer_login" method="post" enctype="multipart/form-data">
Email :<input type="text" name="email" >   email<br/>
password :<input type="password" name="password"> password<br/>
Role(1=customer, 2=service provider):<input type="text" name="role" >   role<br/>
<input type="submit" >
</form>

 
<h2>User Logout Form</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/customer_logout" method="post" enctype="multipart/form-data">
user_id :<input type="text" name="user_id" >   user_id<br/>
<input type="submit" >
</form>


<h2>Forgot Password</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/forgot_password" method="post" enctype="multipart/form-data">
Enter Email :<input type="text" name="email" >   Email<br/>

<input type="submit" >
</form>

<h2>Get all Categories</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_categories_list" method="post" enctype="multipart/form-data">
<input type="submit" >
</form>


<h2>Get Profile Detail</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_profile" method="post" enctype="multipart/form-data">
Enter Id :<input type="text" name="id" >   id<br/>
User Type (1 for customer, 2 for service provider) :<input type="text" name="type"> type<br/>
<input type="submit" >
</form>


<h2>Post job</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/post_job" method="post" enctype="multipart/form-data">
user_id :<input type="text" name="user_id" >   user_id<br/>
job title :<input type="text" name="job_title" >   job_title<br/>

job_cat :<input type="text" name="job_cat" >   job_cat<br/>

Upload Image/Video :<input type="file" name="file" >   file<br/>

Upload Audio :<input type="file" name="audio" >   audio<br/>
		 
Start date:<input type="text" name="start_date" >   start_date,Format yyyy-mm-dd<br/>
Budget :<input type="text" name="budget" >  budget<br/>

Additional comments :<input type="text" name="add_comments" >   add_comments<br/>

End date :<input type="text" name="end_date" >   end_date,Format yyyy-mm-dd<br/>

State:<input type="text" name="state" >   state <br/>
Country:<input type="text" name="country" >   country <br/>
Job Type(1=Direct,2=Indirect ):<input type="text" name="job_type" >   job_type <br/>
<input type="submit" >
</form>

<h2>Job detail(For customer)</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/job_detail" method="post" enctype="multipart/form-data">
Job Id :<input type="text" name="job_id"> job_id<br/>
<input type="submit" >
</form>

<h2>Job Delete</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/job_delete" method="post" enctype="multipart/form-data">
Job Id :<input type="text" name="job_id"> job_id<br/>
<input type="submit" >
</form>


<h2>Edit job</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/edit_post_job" method="post" enctype="multipart/form-data">

job Id :<input type="text" name="job_id" >   job_id<br/>
user_id :<input type="text" name="user_id" >   user_id<br/>

job title :<input type="text" name="job_title" >   job_title<br/>

job_cat :<input type="text" name="job_cat" >   job_cat<br/>

Upload Image/Video :<input type="file" name="file" >   file<br/>

Upload Audio :<input type="file" name="audio" >   audio<br/>
		 
job detail:<input type="text" name="job_detail" >   job_detail<br/>

Budget :<input type="text" name="budget" >  budget<br/>

Additional comments :<input type="text" name="add_comments" >   add_comments<br/>

End date :<input type="text" name="end_date" >   end_date,Format yyyy-mm-dd<br/>

State:<input type="text" name="state" >   state <br/>
Country:<input type="text" name="country" >   country <br/>
<input type="submit" >
</form>

<h2>Posted Job List(For Service Provider)</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_job_list" method="post" enctype="multipart/form-data">
<!--User Id :<input type="text" name="user_id"> user_id<br/>-->
User Type (1 for customer, 2 for service provider) :<input type="text" name="type"> type<br/>
<input type="submit" >
</form>

<h2>Inprogress Job List(For Service Provider)</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_progress_job_list" method="post" enctype="multipart/form-data">
User Id :<input type="text" name="user_id"> user_id<br/>
<input type="submit" >
</form>

<h2>Completed Job List(For Service Provider)</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_completed_job_list" method="post" enctype="multipart/form-data">
User Id :<input type="text" name="user_id"> user_id<br/>
<input type="submit" >
</form>


<h2>Apply job</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/apply_job" method="post" enctype="multipart/form-data">

job Id :<input type="text" name="job_id" >   job_id<br/>
Provider id :<input type="text" name="sp_id" >   sp_id<br/>
cover letter :<input type="text" name="cover_letter" >   cover_letter<br/>
Deleivery date :<input type="text" name="deleivery_date" >   deleivery_date,Format yyyy-mm-dd<br/>
Bid Amount:<input type="text" name="bid_amount" >   bid_amount <br/>
<input type="submit" >
</form>



<h2>List of applied provider for a particular job</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/specific_job_bids" method="post" enctype="multipart/form-data">

job Id :<input type="text" name="job_id" >   job_id<br/>
<input type="submit" >
</form>


<h2>Previously Hired service provider list</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/pre_hired_sp" method="post" enctype="multipart/form-data">

User Id :<input type="text" name="user_id" >   user_id<br/>
<input type="submit" >
</form>


<h2>Hire Service provider </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/hire_sp" method="post" enctype="multipart/form-data">

job Id :<input type="text" name="job_id" >   job_id<br/>
Service provider id :<input type="text" name="sp_id" >   sp_id<br/>
<input type="submit" >
</form>

<h2>Accept/Decline Direct Job proposal By Service provider </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/accept_direct_job_offer" method="post" enctype="multipart/form-data">
job Id :<input type="text" name="job_id" >   job_id<br/>
Service provider id :<input type="text" name="sp_id" >   sp_id<br/>
status(2 for accepted, 3 for decline) :<input type="text" name="status" >   status<br/>
<input type="submit" >
</form>

<h2>End Contract (  )</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/end_contract" method="post" enctype="multipart/form-data">

job Id :<input type="text" name="job_id" >   job_id<br/>
Customer Id :<input type="text" name="c_id" >   c_id<br/>
<input type="submit" >
</form>



<h2>Send message </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/send_message" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="user_id" > user_id<br/>
Friend ID :<input type="text" name="frnd_id" > frnd_id<br/>
Message :<input type="text" name="message" > message<br/>
<!--Attachments:<input type="file" name="attach"  ><br>attach  <br/>-->
<input type="submit">
</form>

<h2>Get chat last 30 message</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_conversation" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="user_id" > user_id<br/>
Friend ID :<input type="text" name="frnd_id" > frnd_id<br/>
<input type="submit">
</form>

<h2>Users list with last message</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/last_message_list" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="user_id" > user_id<br/>
<input type="submit">
</form>


<h2>Update User position</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/update_position" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="user_id" > user_id<br/>
lat :<input type="text" name="lat" > lat<br/>
long :<input type="text" name="long" > long<br/>
<input type="submit">
</form>

<h2>Search service provider within 5 kms </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/get_service_list" method="post" enctype="multipart/form-data">
Category Id :<input type="text" name="cat_id" > cat_id<br/>
lat :<input type="text" name="lat" > lat<br/>
long :<input type="text" name="long" > long<br/>
<input type="submit">
</form>

<h2>Leave Feedback</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/leave_feedback" method="post" >
logged In User Id :<input type="text" name="u_id" >   u_id<br/>
User Id :<input type="text" name="o_id" >   o_id<br/>
Rating :<input type="text" name="rating" >   rating<br/>
<input type="submit" >
</form>


<!--<h2>Forgot your Password</h2>

<form action="http://worktestserver.com/development/Socialpocketing/web_service/forgot_password" method="post" enctype="multipart/form-data">
Email  :<input typ<h2>Send message </h2>
<form action="chat.php" method="post" enctype="multipart/form-data">
Note:-<span style="color:red">service_type=send_message</span><br/>
<input type="hidden" name="service_type" value="send_message">
User ID :<input type="text" name="user_id" > user_id<br/>
Friend ID :<input type="text" name="frnd_id" > frnd_id<br/>
Message :<input type="text" name="message" > message<br/>
<!--Attachments:<input type="file" name="attach"  ><br>attach  <br/>
<input type="submit">
</form>

<h2>Get chat last 30 message</h2>
<form action="chat.php" method="post" enctype="multipart/form-data">
Note:-<span style="color:red">service_type=get_messages</span><br/>
<input type="hidden" name="service_type" value="get_messages">
User ID :<input type="text" name="user_id" > user_id<br/>
Friend ID :<input type="text" name="frnd_id" > frnd_id<br/>

<input type="submit">
</form>

<h2>Get more chat web service</h2>
<form action="chat.php" method="post" enctype="multipart/form-data">
Note:-<span style="color:red">service_type=loadMoreChat</span><br/>
<input type="hidden" name="service_type" value="loadMoreChat">
User ID :<input type="text" name="user_id" > user_id<br/>
Friend ID :<input type="text" name="frnd_id" > frnd_id<br/>
Page No :<input type="text" name="page_no" > page_no<br/>

<input type="submit">
</form>e="text" name="email" >email<br/>
<input type="submit" >
</form>



<h2>Change Password </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/changePassword" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="id" >   id<br/>
New password :<input type="password" name="new_pass"> new_pass<br/>


<input type="submit" >
</form>


<h2>To get Default Setting </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/settings" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="user_id" > user_id<br/>

<input type="submit" >
</form>

<h2>To Update Default Setting </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/update_settings" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="user_id" >   user_id<br/>
Department ID :<input type="text" name="dept_id" >   dept_id<br/>
Assistant ID :<input type="text" name="assist_id" >   assist_id<br/>

<input type="submit" >
</form>

<h2>To get Job List Of particular employee </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/job_list" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="id" >   id<br/>
Date :<input type="text" name="date" >   date<br/>Format yyyy-mm-dd
Note:-date format will be y-m-d<br/>
<input type="submit" >
</form>

<h2>To get Job Detail</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/job_detail" method="post" enctype="multipart/form-data">
Job ID :<input type="text" name="job_id" >   job_id<br/>
<input type="submit" >
</form>

<h2>To get Weekly Summary </h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/weekly_summary" method="post" enctype="multipart/form-data">
User ID :<input type="text" name="id" >   id<br/>
<input type="submit" >
</form>

<h2>To get Customer List</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/customer_list" method="post" enctype="multipart/form-data">
<input type="submit" >
</form>


<h2>To get Assistant List</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/assistant_list" method="post" enctype="multipart/form-data">
<input type="submit" >
</form>

<h2>To get Department List</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/department_list" method="post" enctype="multipart/form-data">
<input type="submit" >
</form>

<h2>To get Customer Job Number</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/customer_job_num" method="post" enctype="multipart/form-data">
Customer ID :<input type="text" name="cust_id" >   cust_id<br/>
<input type="submit" >
</form>

<h2>To Add job</h2>
<form action="http://worktestserver.com/development/Socialpocketing/web_service/add_job" method="post" enctype="multipart/form-data">
		 
job_title :<input type="text" name="job_title" >   job_title<br/>
job_num :<input type="text" name="job_num" >   job_num<br/>
job_Type(pass value 1 for Maintainance, 2 for installation, 3 for service):<input type="text" name="job_type" >   job_type<br/>
job_desc :<input type="text" name="job_desc" >   job_desc<br/>
job_date :<input type="text" name="job_date" >   job_date,Format yyyy-mm-dd<br/>
emp_id :<input type="text" name="emp_id" >   emp_id<br/>
emp_hour:<input type="text" name="emp_hour" >   emp_hour ,Format hh:mm<br/>
assist_ids:<input type="text" name="assist_ids" >   assist_ids,Format ids seperated with ,<br/>
assist_hours:<input type="text" name="assist_hours" >   assist_hours ,Format hh:mm seperated with , <br/>
<input type="submit" >
Note:- Job Date Format yyyy-mm-dd
</form>-->